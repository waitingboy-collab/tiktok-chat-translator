# Live Chat Translator for Mac

A Mac app that translates the comments of any public **TikTok LIVE** in real time. Type the @username, pick a language, press **Start**, and every chat comment appears translated.

- **Nothing to install.** Node.js is built into the app.
- Works on **Apple Silicon (M1–M4) and Intel** Macs, macOS 11 or newer.
- Free: no accounts, no API keys.
- Read-only: nothing is posted to the LIVE chat. The translations are shown only on your screen.

![Live Chat Translator](docs/screenshot.png)

**[⬇ Download for Mac](https://github.com/waitingboy-collab/live-chat-translator-mac/releases/latest/download/Live-Chat-Translator-mac.zip)** · [All releases](https://github.com/waitingboy-collab/live-chat-translator-mac/releases) · **[Инструкции на български ↓](#инструкции-на-български)**

---

## Install

1. **Download** [Live-Chat-Translator-mac.zip](https://github.com/waitingboy-collab/live-chat-translator-mac/releases/latest/download/Live-Chat-Translator-mac.zip).
2. **Double-click the ZIP** in Downloads. You get **Live Chat Translator.app**.
3. **Drag the app to Applications.**
4. **Open it.** The first time, macOS blocks it because it isn't from the App Store:
   1. In the message that appears, click **Done** (or **OK**). Don't move it to the Bin.
   2. Open  **→ System Settings → Privacy & Security**.
   3. Scroll down to *"Live Chat Translator" was blocked…* and click **Open Anyway**. Enter your password.
   4. Click **Open Anyway** once more.

   On macOS 14 and older you can instead **right-click the app → Open → Open**.

   You only do this once. After that it opens normally.

## Use

1. Open **Live Chat Translator**. It opens in its own window (in Chrome or Edge if you have them, otherwise in Safari).
2. Enter the TikTok **username** of the person who is live, or paste the LIVE link.
3. Choose the language under **Translate to**.
4. Press **Start**.

If the person isn't live yet, the app waits and connects by itself when the LIVE starts.

**To close it:** close the window (the app stops by itself after about 30 seconds) or press **Quit** in the top-right corner.

### Options

- **Show original**: shows the original text under each translation.
- **Translate all**: also translates comments that are already in your language.
- **A− / A+**: change the text size.
- **Test translation**: checks the translator without a LIVE.
- **Export .txt**: saves the chat with the translations.

## Troubleshooting

| What you see | What to do |
|---|---|
| *"Live Chat Translator" cannot be opened* / *Apple could not verify…* | Follow step 4 of **Install** (Privacy & Security → **Open Anyway**). |
| *"…is damaged and can't be opened"* | Open **Terminal** and run `xattr -cr "/Applications/Live Chat Translator.app"`, then open the app again. |
| *"… is not live right now"* | Check the username. The app connects by itself when the LIVE starts. |
| *"This LIVE is restricted (18+ or private)"* | These LIVEs can't be read. |
| *"rate limit"* | The free connection service is busy. Wait a minute; it retries by itself. |
| Comments appear but aren't translated | Press **Test translation** and read the message. |
| *"Live Chat Translator could not start"* | Send the file `~/Library/Logs/LiveChatTranslator.log` (Finder → **Go → Go to Folder…** → paste `~/Library/Logs`). |

## For developers

The app is a small local web app (`app/server.js` + `app/public/index.html`) wrapped in a macOS `.app` bundle:

- `mac/launcher.sh` starts the bundled Node.js server on `localhost:3030` and opens the page in an app-style window. The server quits by itself ~30 s after the last window closes.
- Comments come from [tiktok-live-connector](https://github.com/zerodytrash/TikTok-Live-Connector). Translation uses Google's free web endpoints with MyMemory as a fallback.

Build the app (on macOS or Linux, needs Node.js + npm):

```bash
bash build.sh
# → dist/Live Chat Translator.app and dist/Live-Chat-Translator-mac.zip
```

It bundles the official signed Node.js binaries for Apple Silicon and Intel. The app itself is not signed with an Apple Developer ID, which is why macOS asks for confirmation the first time.

Windows / browser version: [waitingboy-collab/tiktok-chat-translator](https://github.com/waitingboy-collab/tiktok-chat-translator).

---

## Инструкции на български

Приложение за Mac, което превежда в реално време коментарите от всеки публичен **TikTok LIVE**. Пишеш @потребителя, избираш език, натискаш **Start** и всеки коментар се показва преведен. Нищо не се пише в чата на лайва, преводите се виждат само на твоя екран.

- **Не се инсталира нищо допълнително.** Node.js е вграден в приложението.
- Работи на **Apple Silicon (M1–M4) и Intel**, macOS 11 или по-нов.

### Инсталиране

1. **Изтегли** [Live-Chat-Translator-mac.zip](https://github.com/waitingboy-collab/live-chat-translator-mac/releases/latest/download/Live-Chat-Translator-mac.zip).
2. **Кликни два пъти на ZIP файла** в Downloads. Получаваш **Live Chat Translator.app**.
3. **Плъзни приложението в Applications.**
4. **Отвори го.** Първия път macOS го спира, защото не е от App Store:
   1. В съобщението натисни **Done** (или **OK**). Не го премествай в кошчето.
   2. Отвори  **→ System Settings → Privacy & Security**.
   3. Слез надолу до *„Live Chat Translator“ was blocked…* и натисни **Open Anyway**. Въведи паролата си.
   4. Натисни още веднъж **Open Anyway**.

   На macOS 14 и по-стари може и така: **десен бутон върху приложението → Open → Open**.

   Това се прави само веднъж. След това се отваря нормално.

### Ползване

1. Отвори **Live Chat Translator**. Отваря се в собствен прозорец (в Chrome или Edge, ако ги имаш, иначе в Safari).
2. Напиши TikTok **потребителското име** на човека, който е на живо, или постави линка към лайва.
3. Избери език в **Translate to** (например Bulgarian).
4. Натисни **Start**.

Ако човекът още не е на живо, приложението чака и се свързва само, когато лайвът започне.

**Затваряне:** затвори прозореца (приложението спира само след около 30 секунди) или натисни **Quit** горе вдясно.

### Ако нещо не работи

- **„cannot be opened“ / „Apple could not verify…“** — направи стъпка 4 от инсталирането (Privacy & Security → **Open Anyway**).
- **„…is damaged and can't be opened“** — отвори **Terminal** и напиши `xattr -cr "/Applications/Live Chat Translator.app"`, после отвори приложението пак.
- **Коментарите излизат, но не се превеждат** — натисни **Test translation** и прочети съобщението.
- **„Live Chat Translator could not start“** — прати файла `~/Library/Logs/LiveChatTranslator.log` (Finder → **Go → Go to Folder…** → `~/Library/Logs`).
